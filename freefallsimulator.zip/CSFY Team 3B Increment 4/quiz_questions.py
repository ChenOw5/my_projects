questions = [{'question': 'Question 1: The maximum velocity an object reaches when falling under the force of gravity is known as what?',
              'choices': ['Maximum velocity','Minimum velocity', 'Velocirapture', 'Terminal velocity'],
              'answer': 'Terminal velocity'},
              
              {'question': 'Question 2: For an object to reach terminal velocity, air resistance must balance the:',
              'choices': ['Height','Weight', 'Geometry', 'Area'],
              'answer': 'Weight'},

              {'question': 'Question 3: An object in free fall __________ as it falls',
              'choices': ['gets slower','gets faster','has a constant speed'],
              'answer': 'gets faster'},

              {'question': 'Question 4: To create the most air drag (resistance), a parachute needs to',
              'choices': ['have a small surface area','be light', 'have a large surface area', 'be heavy'],
              'answer': 'have a large surface area'},

              {'question': 'Question 5: A force that is opposite to motion of a falling object is',
              'choices': ['equilibrium','gravity', 'air drag', 'normal force'],
              'answer': 'air drag'},

              {'question': 'Question 6: Which of the following force will help a skydiver to reach terminal velocity?',
              'choices': ['Force of gravity','Normal force', 'Drag force of air'],
              'answer': 'Drag force of air'},

              {'question': 'Question 7: A falling object will slow down only when _____________',
              'choices': ['force of gravity becomes greater than drag force','normal force becomes greater than gravity', 'drag force of air becomes more than gravity', 'gravity = drag force of air'],
              'answer': 'drag force of air becomes more than gravity'},

              {'question': 'Question 8: An object in equilibrium can still have forces acting on it',
              'choices': ['True','False'],
              'answer': 'True'},

              {'question': 'Question 9: An object travelling at terminal velocity moves in a constant direction',
              'choices': ['True','False'],
              'answer': 'True'},

              {'question': 'Question 10: An object travelling a terminal velocity moves at a steady speed',
              'choices': ['True','False'],
              'answer': 'True'}]