from tkinter import *
import SimulationPage
import random

class MainInterface(Tk):
    def __init__(self):
        super().__init__()
        self.attributes('-fullscreen', True)
        self.title("Free Fall Simulator")
        self.configure(background='aqua')
        def move_shapes():
            # Move each shape downwards
            for shape in shapes:
                canvas.move(shape, 0, 6)  # Move down by 5 pixels
                x1, y1, x2, y2 = canvas.coords(shape)

                # Reset position if the shape moves out of view
                if y1 > canvas_height:
                    canvas.coords(shape, x1, -100, x2, y2 - y1 - 100)

            # Raise the text to the front every time shapes move
            canvas.tag_raise("front_text")
            # Repeat this function every 50 milliseconds
            self.after(50, move_shapes)

        canvas_width = 1440
        canvas_height = 1000

        # Create a canvas widget
        canvas = Canvas(self, width=canvas_width, height=canvas_height, background='aqua')
        canvas.place(x=0, y=0)

        # List to hold all the shapes
        shapes = []

        #cloud = PhotoImage(file='cloud1.png')

        # Create a rectangle
        for _ in range(5):
            y = random.randint(10, 1500)
            x = random.randint(10, 1500)
            rectangle = canvas.create_rectangle(x - 50, y - 50, x + 50, y + 50, fill='lightseagreen')
            shapes.append(rectangle)

        # Create some circles
        for _ in range(5):
            a = random.randint(100, 2000)
            b = random.randint(100, 2000)
            circle = canvas.create_oval(a - 50, b - 50, a + 50, b + 50, fill='blue')
            shapes.append(circle)


        welcomeText = Label(self, text="Welcome to the\nFree Fall Simulator", font=("Times New Roman", 72, "bold"),
                            bg='aqua')
        welcomeText.pack(pady=80)

        self.startButton = Button(self, text="START", font=("Times New Roman", 30, "bold"), command=self.open_simulation, bg='white')
        self.startButton.pack(pady=10)
        
        self.theoryButton = Button(self, text="THEORY & EQUATIONS", font=("Times New Roman", 30, "bold"), command=self.open_TheoryEquation, bg='white')
        self.theoryButton.pack(pady=10)
        
        self.quizButton = Button(self, text="QUIZ", font=("Times New Roman", 30, "bold"), command=self.quiz_page,
                                  bg='white')
        self.quizButton.pack(pady=10)
        
        self.closeButton = Button(self, text="CLOSE", font=("Times New Roman", 30, "bold"), command=self.close, bg='white') 
        self.closeButton.pack(pady=10)
        
        move_shapes()

    def open_simulation(self):
        import SimulationPage
        self.closeCurrentOpenNew(SimulationPage.SimulationInterface)
        
    def open_TheoryEquation(self):
        import TheoryEquation
        self.closeCurrentOpenNew(TheoryEquation.TheoryEquationInterface)
        
    def quiz_page(self):
        import quiz_page
        self.closeCurrentOpenNew(quiz_page.QuizApp)
        
    def close(self):
        self.destroy()
        self.quit()

    def closeCurrentOpenNew(self, window):
        self.withdraw()
        self.wait_window(window())
        self.deiconify()    
        self.update()

    
if __name__ == '__main__':
    root = MainInterface()
    root.mainloop()