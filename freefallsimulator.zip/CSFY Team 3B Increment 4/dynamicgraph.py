import tkinter as tk
from tkinter import ttk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
import numpy as np

class DynamicGraphApp:
    def __init__(self, master,gravity, initial_height, mass, cross_area, fluid_density, shape,start):
        self.master = master

        self.drag_co = 1.0
        if shape == "cube":
            self.drag_co = 1.05
        elif shape == "sphere":
            self.drag_co = 0.47
        elif shape == "cylinder":
            self.drag_co = 0.82

        # Set initial values (change as needed)
        self.m = mass  # mass in kg
        self.density = fluid_density  # fluid density in kg/m^3 (air density)
        self.A = cross_area  # cross-sectional area in m^2
        self.Cd = self.drag_co # drag coefficient
        self.height = initial_height  # initial height in meters
        self.is_running = False  # simulation running flag
        self.gravity = gravity
        self.t = 0

        # Create labels and sliders
        self.create_widgets()

        # Initialize plots with adjusted layout
        self.create_graphs()
        
        # Create arrays to store data
        self.times = []
        self.velocities = []
        self.accelerations = []
        self.displacements = []

        if start == 1 :
            self.create_buttons()
            self.start_simulation()
        else :
            self.ax1.set_xlabel("Time (s)")
            self.ax1.set_ylabel("Acceleration (m/s²)")
            self.ax1.set_title("Acceleration vs Time")

            self.ax2.set_xlabel("Time (s)")
            self.ax2.set_ylabel("Velocity (m/s)")
            self.ax2.set_title("Velocity vs Time")
            self.canvas.draw()
            pass

        # Plot initial data

    def create_graphs(self):
        self.fig, (self.ax1, self.ax2) = plt.subplots(2, 1, figsize=(3, 6))
        self.fig.subplots_adjust(hspace=0.5)
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.master)
        self.canvas.get_tk_widget().grid(row=7, column=0, columnspan=3, pady=(50, 50),padx=70)

    def create_widgets(self):
        self.status_label = tk.Label(self.master, text="Status:",font=("Arial,16"))
        self.status_label.grid(row=5, column=0, columnspan=2,pady=20,padx=10)

    def create_buttons(self):
        self.buttons_frame = tk.Frame(self.master)
        self.buttons_frame.grid(row=6, column=0, columnspan=3, pady=(5, 2), padx=5)

        self.start_button = tk.Button(self.buttons_frame, text="Start", command=self.start_simulation, width=10)
        self.start_button.pack(side=tk.LEFT, padx=(10,5))

        self.pause_button = tk.Button(self.buttons_frame, text="Pause", command=self.pause_simulation, state=tk.DISABLED, width=10)
        self.pause_button.pack(side=tk.LEFT, padx=5)

        self.reset_button = tk.Button(self.buttons_frame, text="Reset", command=self.reset_simulation, state=tk.DISABLED, width=10)
        self.reset_button.pack(side=tk.LEFT, padx=5)

    def update_mass(self, value):
        if not self.is_running:
            self.m = float(value)
            self.mass_value_label.config(text=f"{self.m:.2f}")

    def update_density(self, value):
        if not self.is_running:
            self.density = float(value)
            self.density_value_label.config(text=f"{self.density:.2f}")

    def update_area(self, value):
        if not self.is_running:
            self.A = float(value)
            self.area_value_label.config(text=f"{self.A:.2f}")

    def update_cd(self, value):
        if not self.is_running:
            self.Cd = float(value)
            self.cd_value_label.config(text=f"{self.Cd:.2f}")

    def update_height(self, value):
        if not self.is_running:
            self.height = float(value)
            self.height_value_label.config(text=f"{self.height:.2f}")

    def start_simulation(self):
        self.is_running = True
        self.start_button.config(state=tk.DISABLED)
        self.pause_button.config(state=tk.NORMAL)
        self.reset_button.config(state=tk.DISABLED)
        self.start_timer()

    def pause_simulation(self):
        self.is_running = False
        self.start_button.config(state=tk.NORMAL)
        self.pause_button.config(state=tk.DISABLED)
        self.reset_button.config(state=tk.NORMAL)
        self.stop_timer()
        self.status_label.config(text="Status: Paused")

    def reset_simulation(self):
        self.is_running = False
        self.start_button.config(state=tk.NORMAL)
        self.pause_button.config(state=tk.DISABLED)
        self.reset_button.config(state=tk.DISABLED)
        self.stop_timer()
        self.times.clear()
        self.velocities.clear()
        self.accelerations.clear()
        self.displacements.clear()
        self.t = 0.0
        self.ax1.clear()
        self.ax2.clear()
        self.plot_data()
        self.status_label.config(text="Status:")

    def start_timer(self):
        self.timer_id = self.master.after(1, self.update_plot)

    def stop_timer(self):
        if hasattr(self, "timer_id"):
            self.master.after_cancel(self.timer_id)
            del self.timer_id

    def update_plot(self):
        if not self.is_running:
            return
    
        self.t += 0.1
        g = self.gravity
        v_terminal = np.sqrt(   (2 * self.m * g) / (self.density * self.A * self.Cd) )
        
        v = np.tanh(float(self.gravity)*float(self.t)/float(v_terminal)) * v_terminal
        
        a = (g - (self.Cd * self.density * self.A * v**2) / (2 * self.m))
        
        d = (v_terminal**2 / g) * np.log(np.cosh(g * self.t / v_terminal))

        if d >= self.height:
            v = 0
            a = 0

        self.times.append(self.t)
        self.velocities.append(v)
        self.accelerations.append(a)
        self.displacements.append(d)

        self.ax1.clear()
        self.ax1.plot(self.times, self.accelerations, 'b-')
        self.ax1.set_xlabel("Time (s)")
        self.ax1.set_ylabel("Acceleration (m/s²)")
        self.ax1.set_title("Acceleration vs Time")

        self.ax2.clear()
        self.ax2.plot(self.times, self.velocities, 'r-')
        self.ax2.set_xlabel("Time (s)")
        self.ax2.set_ylabel("Velocity (m/s)")
        self.ax2.set_title("Velocity vs Time")

        self.canvas.draw()

        if v == 0 and a == 0:
            self.pause_simulation()
            self.status_label.config(text="Status: Landed")
            return

        if v != 0 and abs(a) < 0.01:
            self.status_label.config(text="Status: Terminal Velocity Reached")
        elif v != 0 and a != 0:
            self.status_label.config(text="Status: Falling")
        else:
            self.status_label.config(text="Status: Landed")

        self.timer_id = self.master.after(1, self.update_plot)

    def plot_data(self):
        self.ax1.plot([0], [0], 'b-')
        self.ax1.set_xlabel("Time (s)")
        self.ax1.set_ylabel("Acceleration (m/s²)")
        self.ax1.set_title("Acceleration vs Time")

        self.ax2.plot([0], [0], 'r-')
        self.ax2.set_xlabel("Time (s)")
        self.ax2.set_ylabel("Velocity (m/s)")
        self.ax2.set_title("Velocity vs Time")

        self.canvas.draw()
    
def close(self):
    self.master.destroy()
        
# if __name__ == "__main__":
#     root = tk.Tk()
#     app = DynamicGraphApp(root)
#     root.mainloop()
