import tkinter as tk
import math
import time
import equations
import numpy as np
import dynamicgraph

global height
global pause
pause = False
height = 0
velocity = 0
gravity = 9.81
initial_height = 100
mass = 5
cross_area = 1
fluid_density = 1.225
shape = "cube"

class FreeFallSimulator:
    def __init__(self,main,gravity, initial_height, mass, cross_area, fluid_density, shape):
        self.drag_co = 1.0
        if shape == "cube":
            self.drag_co = 1.05
        elif shape == "sphere":
            self.drag_co = 0.47
        elif shape == "cylinder":
            self.drag_co = 0.82
        
        self.variables_var = equations.variables(main, gravity, initial_height, mass, cross_area, fluid_density, self.drag_co)
        self.height = initial_height
    

    def update_mainlabel1(self):
        global height
        if self.variables_var.get_height() > 0: 
            self.variables_var.update_label()
            height = self.variables_var.get_height()

def close(x):
    equations.variables.close(x)