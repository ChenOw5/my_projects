import tkinter as tk
from tkinter import messagebox
from tkinter.ttk import Style
from quiz_questions import questions
import threading

class QuizApp(tk.Toplevel):
    def __init__(self):
        super().__init__()
        self.title('Quiz')
        self.attributes('-fullscreen', True)
        self.style = Style()
        self.style.theme_use('clam')
        self.fontsize27 = int(self.winfo_height() * 0.03)
        self.fontsize20 = int(self.fontsize27 / (74 / 99)) 
        self.fontsize36 = int(self.fontsize27 * (4 / 3)) 
        self.fontsize24 = int(self.fontsize27 * (8 / 9)) 
        self.fontsize15 = int(self.fontsize27 * (5 / 9)) 
        self.fontsize25 = int(self.fontsize27 * (925 / 999))
        self.style.configure('TLabel', font=('Times new roman', self.fontsize36))
        self.style.configure('TButton', font=('Times new roman', self.fontsize24))

        self.current_question = 0
        self.score_value = 0
        self.user_answers = []

        self.question_label = tk.Label(self, anchor='center', wraplength=1000, font=('Times new roman', self.fontsize27))
        self.question_label.pack(padx=20, pady=20)

        self.feedback_label = tk.Label(self, anchor='center', wraplength=1000, font=('Times new roman', self.fontsize27))
        self.feedback_label.pack(padx=20, pady=20)

        self.choices_frame = tk.Frame(self)
        self.choices_frame.pack(padx=20, pady=20)

        self.score_label = tk.Label(self, text='Score: 0/{}'.format(len(questions)), anchor='center', font=('Times new roman', self.fontsize24))
        self.score_label.pack(padx=20, pady=20)

        self.choice_buttons = []

        self.next_question_button = tk.Button(self, text='Next', command=self.next_question, state='disabled', font=('Times new roman', self.fontsize24))
        self.next_question_button.pack(padx=20, pady=20)

        self.timer_label = tk.Label(self, text='Time Left: 15 s', anchor='nw', font=('Times new roman', self.fontsize24))
        self.timer_label.pack(padx=20, pady=20)

        self.show_question()

    def create_choice_buttons(self, num_choices):
        for button in self.choice_buttons:
            button.destroy()
        self.choice_buttons.clear()

        for i in range(num_choices):
            button = tk.Button(self.choices_frame, command=lambda i=i: self.check_answer(i), font=('Times new roman', self.fontsize20))
            button.pack(pady=10)
            self.choice_buttons.append(button)

    def next_question(self):
        self.current_question += 1

        if self.current_question < len(questions):
            self.show_question()
        else:
            self.show_result_page()

    def check_answer(self, choice):
        question = questions[self.current_question]
        selected_answer = self.choice_buttons[choice].cget('text') 

        if selected_answer == question['answer']:
            self.score_value += 1
            self.score_label.config(text='Score: {}/{}'.format(self.score_value, len(questions)))
            self.feedback_label.config(text='Correct!', foreground='green')
        else:
            correct_answer = question['answer']
            feedback_text = 'Incorrect! Answer: {}'.format(correct_answer)
            self.feedback_label.config(text=feedback_text, foreground='red')

        question['user_choice'] = choice

        for button in self.choice_buttons:
            button.config(state='disabled')
        self.next_question_button.config(state='normal')
        self.stop_timer()

    def show_question(self):
        question = questions[self.current_question]
        self.question_label.config(text=question['question'])

        choices = question['choices']
        num_choices = len(choices)

        self.create_choice_buttons(num_choices)

        for i in range(num_choices):
            self.choice_buttons[i].config(text=choices[i], state='normal')
        self.start_countdown()

    def start_countdown(self):
        self.countdown_timer = 15
        self.update_timer_label()
        threading.Thread(target=self.run_countdown).start()

    def run_countdown(self):
        if self.countdown_timer >= 0:
            self.update_timer_label()
            self.countdown_timer -= 1
            self.after(1000, self.run_countdown)
        else:
            if not self.choice_buttons[0]['state'] == 'disabled':
                question = questions[self.current_question]
                correct_answer = question['answer']
                feedback_text = 'Time\'s up! Answer: {}'.format(correct_answer)
                self.feedback_label.config(text=feedback_text, foreground='red')
                for button in self.choice_buttons:
                    button.config(state='disabled')
                self.next_question_button.config(state='normal')

    def update_timer_label(self):
        self.timer_label.config(text=f'Time Left: {self.countdown_timer} s')

    def stop_timer(self):
        self.countdown_timer = -1

    def show_result_page(self):
        result_window = tk.Toplevel()
        result_window.title("Quiz Result")
        result_window.attributes('-fullscreen', True)

        tk.Label(result_window, text="Quiz Completed!", font=('Times new roman', self.fontsize25)).pack(pady = 10)
        tk.Label(result_window, text=f"Your Score: {self.score_value}/{len(questions)}", font=('Times new roman', self.fontsize20)).pack()
        if len(self.user_answers) < len(questions):
            unanswered_questions = len(questions) - len(self.user_answers)
            unanswered_label = tk.Label(result_window, text=f"You did not respond to {unanswered_questions} question(s)", font=('Times new roman', self.fontsize20))
            unanswered_label.pack()

        for i, question in enumerate(questions, start=1):
            question_label = tk.Label(result_window, text=f"{question['question']}", font=('Times new roman', self.fontsize15))
            question_label.pack()

            if 'user_choice' in question:
                user_answer = question['choices'][question['user_choice']]
                answer_label = tk.Label(result_window, text=f"Your Answer: {user_answer}", font=('Times new roman', self.fontsize15), fg='blue')
                answer_label.pack()

                if user_answer == question['answer']:
                    correctness_label = tk.Label(result_window, text="Correct!", font=('Times new roman', self.fontsize15), fg='green')
                else:
                    correctness_label = tk.Label(result_window, text=f"Incorrect! Answer: {question['answer']}", font=('Times new roman', self.fontsize15), fg='red')
                correctness_label.pack()
            else:
                no_response_label = tk.Label(result_window, text="No response!", font=('Times new roman', self.fontsize15), fg='red')
                no_response_label.pack()
                correct_answer_label = tk.Label(result_window, text=f"Answer: {question['answer']}", font=('Times new roman', self.fontsize15), fg='red')
                correct_answer_label.pack()

        def close_windows():
            result_window.destroy()
            self.destroy()

        quit_button = tk.Button(result_window, text="Back", command=close_windows, font=('Times new roman', self.fontsize20))
        quit_button.place(relx = 0.92, rely = 0.9)
        
        if __name__ == "__main__":
            root = tk.Tk()
            app = QuizApp(root)
            root.mainloop()
