import tkinter
from tkinter import *
import math
import equations
from tkinter import filedialog
from PIL import Image, ImageTk 



class TheoryEquationInterface(tkinter.Toplevel):
    def __init__(self):
        super().__init__()
        self.title("Theory & Equation")
        self.attributes('-fullscreen', True)
        self.frame = Frame(self)
        self.frame.config(bg='white')
        self.frame.pack(fill=tkinter.BOTH, expand=True)
        self.canvas = Canvas(self.frame)
        self.canvas.config(bg='white')
        self.canvas.place(anchor=CENTER,relx=0.5,rely=0.5,relheight=1,width=3)
        self.frame.update()
        x = self.frame.winfo_height()
        font_size = x/43.2
        font_size = int(font_size)
                
        self.canvas.create_line(0,0,0,x, dash=(int(x/15)), width=3,fill="black")

        drag_label1 = Label(self.frame,text="Drag Force ( N ) acting on an object can be calculated using:", font=("Times New Roman", font_size, "bold"), bg="white")
        drag_label2 = Label(self.frame,anchor=W,text="p = density of the fluid\nu = velocity of the object\nCd = drag coefficient\nA = cross sectional area", font=("Times New Roman", font_size), bg="white")

        drag_label1.place(anchor="center",relx=0.25,rely=0.1)
        drag_label2.place(anchor="center",relx=0.25,rely=0.4)

        velc_label1 = Label(self.frame,text="Velocity of an object with consideration of air resistance is:", font=("Times New Roman", font_size, "bold"), bg="white")
        velc_label2 = Label(self.frame,anchor=W,text="V = terminal velocity\ng = gravitational acceleration\nt = time", font=("Times New Roman", font_size), bg="white")
        velc_label3 = Label(self.frame,text="v(t) = V tanh(gt/V)", font=("Times New Roman", font_size*2), bg="white")

        velc_label1.place(anchor="center",relx=0.25,rely=0.6)
        velc_label2.place(anchor="center",relx=0.25,rely=0.9)
        velc_label3.place(anchor="center",relx=0.25,rely=0.75)
                
        time_label1 = Label(self.frame,text="Time to take for object to reach the ground:", font=("Times New Roman", font_size, "bold"),bg="white")
        time_label2 = Label(self.frame,anchor=W,text="t = time\nh = initial height\nvt = terminal velocity", font=("Times New Roman", font_size), bg="white")
        time_label3 = Label(self.frame,text="t = h / vt", font=("Times New Roman", font_size*2), bg="white")

        time_label1.place(anchor="center",relx=0.75,rely=0.1)
        time_label2.place(anchor="center",relx=0.75,rely=0.4)
        time_label3.place(anchor="center",relx=0.75,rely=0.25)
        
        self.drag_force_image = tkinter.PhotoImage(file="drag-force-equation.png")
        self.drag_scaled_image = self.drag_force_image.subsample(3, 3)
        
        image = Label(self.frame,image=self.drag_scaled_image,bg="white")
        image.place(anchor="center",relx=0.25,rely=0.2)

        self.back_button = Button(self.frame, text="Back to Homepage", font=("Times New Roman", 18, "bold"), command=self.back_to_homepage, bg="aqua", borderwidth=2)
        self.back_button.place(relx=0.8, rely=0.9)

    def back_to_homepage(self):
        self.destroy()  # Close the current window