import tkinter as tk
from decimal import Decimal
import math
import numpy as np

class variables:
    def __init__(self, master, gravity,initial_height1,mass1,surface_area1,fluid_density,drag_co):
        self.timelabel=tk.Label(master,font=("Arial",16))
        self.timelabel.place(anchor='w',relx=0,rely=0.42)
        self.count = Decimal('0')
        
        self.heightlabel=tk.Label(master,font=("Arial",16))
        self.heightlabel.place(anchor='w',relx=0,rely=0.46)
        
        self.velclabel=tk.Label(master,font=("Arial",16))
        self.velclabel.place(anchor='w',relx=0,rely=0.50)
        self.velc = Decimal('0')
        self.velc1 = Decimal('0')
        
        self.acclabel = tk.Label(master,font=("Arial",16))
        self.acclabel.place(anchor='w',relx=0.,rely=0.54)
        self.acc = Decimal('0')
        
        self.draglabel=tk.Label(master,font=("Arial",16))
        self.draglabel.place(anchor='w',relx=0,rely=0.58)
        self.drag = Decimal('0')
        
        self.terminalvelclabel=tk.Label(master,font=("Arial",16))
        self.terminalvelclabel.place(anchor='w',relx=0,rely=0.63)
        self.terminalv = Decimal('0')
        
        self.dragcolabel=tk.Label(master,font=("Arial",16))
        self.dragcolabel.place(anchor='w',relx=0,rely=0.70)
        self.drag_co_shape = Decimal('0')
        
        self.gravity = gravity
        self.initial_height = initial_height1
        self.height = self.initial_height
        self.mass = mass1
        self.sa = surface_area1
        self.fluid_density = fluid_density
        self.drag_co_shape = drag_co
        
        self.update_label()
        
        self.terminalv = math.floor((terminalvelc(self.gravity,self.mass,self.sa,self.fluid_density,self.drag_co_shape))*1000)/1000
        self.terminalvelclabel.configure(text = 'Terminal Velocity: \n {} m/s'.format(self.terminalv))
        self.dragcolabel.configure(text = 'Drag Coefficient of Shape: \n {}'.format(self.drag_co_shape))

    def update_label(self):
        self.timelabel.configure(text = 'Timer: {} s'.format(self.count))
        self.heightlabel.configure(text = 'Height: {} m'.format(self.height))
        self.velclabel.configure(text = 'Velocity: {} m/s'.format(self.velc))
        self.acclabel.configure(text = 'Acceleration: {} m/s^2'.format(self.acc))
        self.draglabel.configure(text = 'Drag Force: {} N'.format(self.drag))
        self.count += Decimal('0.001')
        self.height = math.floor((heightfunc(self.height,self.velc))*1000)/1000
        self.velc = math.floor((velcfunc(self.count,self.gravity,self.terminalv))*1000)/1000
        self.acc = math.floor((accfunction(self.velc1,self.velc))*10)/10
        self.velc1 = self.velc
        self.drag = math.floor((dragf(self.sa,self.fluid_density,self.drag_co_shape,self.velc))*1000)/1000
                
    def get_time(self):
        return self.count
    
    def get_height(self):
        return self.height
    
    def get_velc(self):
        return self.velc
    
    def get_acc(self):
        return self.acc    
    
    def get_drag(self):
        return self.drag
        
    def destroy_widgets(self):
        self.timelabel.destroy()
        self.heightlabel.destroy()
        self.velclabel.destroy()
        self.acclabel.destroy()
        self.draglabel.destroy()
        self.terminalvelclabel.destroy()
    
def heightfunc(x,y):
    return float(x) - float(y)*0.001

def velcfunc(t,g,vt):
    if vt != 0 :
        return float(vt) * np.tanh(float(g)*float(t)/float(vt))
    else :
        return float(vt)

def terminalvelc(g,m,a,fd,dc):
    return pow( ( (2*m*g) / (fd*a*dc) ) ,0.5 )

def dragco_equation(a,fd,dc):
    return (0.5*dc*fd*a)
    
def dragf(a,fd,dc,v):
    return 0.5* float(a) * float(fd) * float (dc) * (float(v) ** 2)

def accfunction(v1,v2):
    return (float(v2)-float(v1))/0.001





