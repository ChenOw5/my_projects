from tkinter import *
from tkinter import messagebox
import equations
import maincalculations
import dynamicgraph
import threading

class SimulationInterface(Toplevel):
    def __init__(self) -> None:
        super().__init__()
        self.simulator = None
        
        self.check = 1

        self.attributes('-fullscreen', True)
        self.title("Free Fall Simulator")
        self.configure(bg="white")
        self.resizable(False, False)
        
        self.pause = False
        
        self.animation_canvas = Canvas(self, bg = 'white')
        self.animation_canvas.place(relx = 0, rely=0,relheight=1,relwidth=0.3333333)
        
        self.animation_canvas.update()
        
        self.shape_coords = {
            "cube": (270, 0, 370, 100),   #  coordinates for a cube
            "sphere": (270, 0, 370, 100),
            "cylinder":(270, 0, 320, 100) 
        }

        self.shape = None

        self.frame1 = Frame(self, bg = 'white')
        self.frame1.place(relx = 0.666666, rely = 0,relheight=1,relwidth=0.3333333)

        self.frame = Frame(self, bg='aqua')
        self.frame.place(relx = 0.5, rely = 0.5, anchor = CENTER ,relheight=1,relwidth=0.3333333)

        global shape
        shape = ""

        # Placeholder text for Entry widgets
        self.entry_placeholders = {
            'Mass': ['1 - 100', 'kg'],
            'Surface Area': ['1 - 5', 'm^2'],
            'Gravitational \nAcceleration': ['9.81', 'm/s^2'],
            'Initial Height': ['1 - 1000', 'm'],
            'Fluid Density': ['1.293', 'kg/m^3']
        }

        # Create Entry widgets and set placeholder text
        self.entries = {}
        self.initial_values = {}
        row_positions = [280, 330, 380, 450, 500]  # Y positions for entries
        for i, (label_text, info) in enumerate(self.entry_placeholders.items()):
            label = Label(self.frame, text=label_text + ': ', font=("Times New Roman", 20), bg="aqua", fg="Black")
            label.place(x=20, y=row_positions[i])

            entry = Entry(self.frame, font=('Times New Roman', 18), fg="Grey", width=10)
            entry.place(x=200, y=row_positions[i])
            entry.insert(0, info[0])

            unit = Label(self.frame, text=info[1], font=("Times New Roman", 20), bg="aqua", fg="Black")
            unit.place(x=330, y=row_positions[i])

            entry.bind('<FocusIn>', lambda event, widget=entry, placeholder=info[0]: self.on_entry_focus_in(widget, placeholder))
            entry.bind('<FocusOut>', lambda event, widget=entry, placeholder=info[0]: self.on_entry_focus_out(widget, placeholder))
            self.entries[label_text] = entry
            self.initial_values[label_text] = info[0]

        self.shape_object = self.shape_object = self.animation_canvas.create_rectangle(260, 0, 360, 100, fill="", outline="")
        
        # Reset Button
        self.resetButton = Button(self.frame, text="Reset", font=("Times New Roman", 20, "bold"), bg='white', command=self.reset_values)
        self.resetButton.place(rely = 0.8, relx= 0.33,anchor=CENTER)

        # Start Button
        self.startButton = Button(self.frame, text="Start", font=("Times New Roman", 20, "bold"), bg='white', command=self.start_simulation)
        self.startButton.place(rely = 0.8, relx= 0.66,anchor=CENTER)
        
        self.skipButton = Button(self.frame, text="Skip Animation", font=("Times New Roman", 20, "bold"), bg='white', command=self.skip_animation)
        self.skipButton.place(rely = 0.73, relx= 0.5,anchor=CENTER)
        
        dynamicgraph.DynamicGraphApp(self.frame1,0,0,0,0,0,"",0)          

        def cube():
            global shape
            shape = "cube"
            x1, y1, x2, y2 = 270, 0, 370, 100
            self.animation_canvas.delete("all")
            self.shape_object = self.animation_canvas.create_rectangle(x1, y1, x2, y2, fill="light blue")
        
        def sphere():
            global shape
            shape = "sphere"
            x1, y1, x2, y2 = 270, 0, 370, 100
            self.animation_canvas.delete("all")
            self.shape_object = self.animation_canvas.create_oval(x1, y1, x2, y2, fill="deepskyblue3")
            
        def cylinder():
            global shape
            shape = "cylinder"
            x1, y1, x2, y2 = 270, 0, 320, 100
            self.animation_canvas.delete("all")
            self.shape_object = self.animation_canvas.create_rectangle(x1, y1, x2, y2, fill="deepskyblue4")

        # Shape (sphere)
        self.shapeLabel = Label(self.frame, text="Pick an object: ", font=("Times New Roman", 20), bg="aqua", fg="black")
        self.shapeLabel.place(relx=0.15,rely=0.05)
        
        sphere_button = PhotoImage(file="sphere2.0.png")
        self.sphereButton = sphere_button.subsample(1,1)
        Button(self.frame, image=self.sphereButton, command=sphere, borderwidth=0, bg="aqua").place(anchor=CENTER,relx=0.25,rely=0.2)

        # Shape (cube)
        cube_button = PhotoImage(file="cube.png")
        self.cubeButton = cube_button.subsample(1,1)
        Button(self.frame, image=self.cubeButton, command=cube, borderwidth=0, bg="aqua").place(anchor=CENTER,relx=0.5,rely=0.2)

        cylinder_button = PhotoImage(file="cylinder.png")
        self.cylinderButton = cylinder_button.subsample(1,1)
        Button(self.frame, image=self.cylinderButton, command=cylinder, borderwidth=0, bg="aqua").place(anchor=CENTER,relx=0.75,rely=0.2)

        home = PhotoImage(file="homeIcon45.png")
        self.home = home.subsample(1, 1)
                
        self.back_button = Button(self.frame, image=self.home, bg="white", command=self.back_to_homepage, borderwidth=2)
        self.back_button.place(anchor=CENTER,relx=0.5,rely=0.95)
    

    def animate_shape(self,initial_height):
        global shape
        # Move the shape downward (simulate falling)
        if maincalculations.pause == False:
            if self.animation_canvas.coords(self.shape_object):
                x1, y1, x2, y2 = self.animation_canvas.coords(self.shape_object)
            elif shape == "cube" or "sphere" :
                x1, y1, x2, y2 = 270, 0, 370, 100
            else :
                x1, y1, x2, y2 = 270, 0, 320, 100
            ratio = maincalculations.height/initial_height
            ratio = 1 - ratio
            y2 = (self.animation_canvas.winfo_height()-100) * ratio
            y1 = y2 + 100
            
            self.animation_canvas.delete("all")

            if shape == "cube":
                self.shape_object = self.animation_canvas.create_rectangle(x1, y1, x2, y2, fill="light blue")
            elif shape == "sphere":
                self.shape_object = self.animation_canvas.create_oval(x1, y1, x2, y2, fill="deepskyblue3")
            elif shape == "cylinder":
                self.shape_object = self.animation_canvas.create_rectangle(x1, y1, x2, y2, fill="deepskyblue4")
            
            # Get the current position of the shape
            
            # Check if the shape has reached the ground (adjust threshold as needed)
            if y2 >= self.animation_canvas.winfo_height():
                return
        
        # Schedule the next frame of animation
        # self.after(1, lambda:self.animate_shape(initial_height))

    def on_entry_focus_in(self,widget, placeholder):
        if widget.get() == placeholder:
            widget.delete(0, END)
            widget.config(fg="black")

    def on_entry_focus_out(self,widget, placeholder):
        if widget.get() == '':
            widget.insert(0, placeholder)
            widget.config(fg="grey")

    def reset(self):
        global t1, t2, t3
        self.animation_canvas.delete("all")
        for widget in self.frame1.winfo_children():
            widget.destroy()
        for widget in self.animation_canvas.winfo_children():
            widget.destroy()
        dynamicgraph.DynamicGraphApp(self.frame1,0,0,0,0,0,"",0)   
        self.animation_canvas
        
    def reset_values(self):
    # Reset all Entry widgets to their initial placeholder values
        self.animation_canvas.configure(background="white")
        self.frame1.configure(background="white")
        self.pause = False
        self.startButton.configure(text="Start", font=("Times New Roman", 20, "bold"), bg='white', command=self.start_simulation)
        self.startButton.update()  
        global shape
        shape = ""
        for label_text, entry in self.entries.items():
            entry.delete(0, END)
            entry.insert(0, self.initial_values[label_text])
            entry.config(fg="grey")
        self.reset()
        
    def back_to_homepage(self):
        self.frame1.destroy()
        self.frame.destroy()
        self.animation_canvas.destroy()
        self.destroy()  # Close the current window
    
    def simulation(self,gravity, initial_height, mass, cross_area, fluid_density, shape):
        self.simulator = maincalculations.FreeFallSimulator(self.animation_canvas,gravity, initial_height, mass, cross_area, fluid_density, shape)   
        self.simulationloop(gravity, initial_height, mass, cross_area, fluid_density, shape)
        
    def simulationloop(self,gravity, initial_height, mass, cross_area, fluid_density, shape):
        if self.pause == False:    
            self.simulationtick(initial_height)
        if maincalculations.height <= 0 or self.check == 0:
            self.animation_canvas.configure(bg = 'white')
            self.frame1.configure(bg="light green")
            self.pause = False
            self.start_graph(gravity, initial_height, mass, cross_area, fluid_density, shape)
            self.startButton.configure(text="Restart", font=("Times New Roman", 20, "bold"), bg='white', command=self.start_simulation)
            self.startButton.update() 
            return
        self.animation_canvas.after(1,lambda:self.simulationloop(gravity, initial_height, mass, cross_area, fluid_density, shape))
        
              
    def simulationtick(self,initial_height):
        if self.simulator:
            self.simulator.update_mainlabel1()
        self.animate_shape(initial_height)
    
    def start_simulation(self):
        self.check = 1
        global t1, t2, t3
        error = []
        global shape
        if shape == "":
            error.append("A Shape Must Be Chosen")
        i = 0
        # Check if all Entry values are integers
        for label_text, entry in self.entries.items():
            i = i+1
            try:
                value = float(entry.get())
            except:
                error.append(f"{label_text} value must be a float value")
                continue
            else:
                if value <= 0 :
                    error.append(f"{label_text} Value Must Be Greater Than 0")
                if i == 1:
                    mass = value
                elif i == 2:
                    cross_area = value
                elif i == 3:
                    gravity = value
                elif i == 4:
                    initial_height = value
                elif i == 5:
                    fluid_density = value
        if error :
            messagebox.showerror("Error", "\n".join(error))
            return
        for widget in self.animation_canvas.winfo_children():
            widget.destroy()
        for widget in self.frame1.winfo_children():
            widget.destroy()
        dynamicgraph.DynamicGraphApp(self.frame1,0,0,0,0,0,"",0) 
        self.animation_canvas.configure(bg = 'light green')
        self.frame1.configure(bg = 'white')
        self.simulation(gravity, initial_height, mass, cross_area, fluid_density, shape)
        self.continue_simulation()
        
        
        #dynamicgraph.DynamicGraphApp(self.frame1,gravity, initial_height, mass, cross_area, fluid_density, shape,1) 
                 
    def start_graph(self, gravity, initial_height, mass, cross_area, fluid_density, shape):
        self.frame1.configure(background="light green")
        for widget in self.frame1.winfo_children():
            widget.destroy()
        dynamicgraph.DynamicGraphApp(self.frame1,gravity, initial_height, mass, cross_area, fluid_density, shape,1)          
        
    def pause_simulation(self):
        self.animation_canvas.configure(background="white")
        self.pause = True
        self.startButton.configure(text="Continue", font=("Times New Roman", 20, "bold"), bg='white', command=self.continue_simulation)
        self.startButton.update()
        
    def continue_simulation(self):
        self.animation_canvas.configure(background="light green")
        self.pause = False
        self.startButton.configure(text="Pause", font=("Times New Roman", 20, "bold"), bg='white', command=self.pause_simulation)
        self.startButton.update()

    def skip_animation(self):
        self.animation_canvas.configure(background="white")
        self.check = 0
         

        