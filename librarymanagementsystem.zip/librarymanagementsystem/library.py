import json
print("Welcome to the Library")

file_path = r"library.json"

#load the json file, if theres nothing, set it to nothing
with open(file_path,"r") as file:
    library = json.load(file)

# function for adding books, im using a dictionary for this
def addbook(ISBN):
    #check if there are 10 to 13 digits
    if len(ISBN) != 10 and len(ISBN) != 13 :
        print("------------------------------------------------------")
        print("Error : ISBN must be 10 or 13 digits")
    #inputting details part
    else : 
        library[ISBN] = {"title":str(input("Enter Book Title: ")).title(),
                     "author":str(input("Enter Book Author: ")).title(),
                     "genre":str(input("Enter Book Genre: ")).title(),
                     "year":int(input("Enter Publication Year: ")),
                     "amount":int(input("Enter Input Amount: ")),
                     "availible":int(0),
                     "loaned":int(input("Enter Loaned Amount: "))}
        library[ISBN]["availible"] = int(int( library[ISBN]["amount"]) - int(library[ISBN]["loaned"]))

#function for priting the details of a selected book
def printdetails(ISBN,book_info):
    print(f"ISBN: {ISBN}") 
    print(f"Title: {book_info['title']}") 
    print(f"Author: {book_info['author']}") 
    print(f"Genre: {book_info['genre']}")
    print(f"Publication Year: {book_info['year']}")
    print(f"Amount: {book_info['amount']}")
    print(f"Availible Amount: {book_info['availible']}")
    print(f"Loaned Amount: {book_info['loaned']}")
    
#function for removing a book from the library
def removebook(ISBN):
    print("------------------------------------------------------")
    print("Are you sure you want to delete this Entry?")
    print("Type 1 To Confirm")
    print("Type 2 To Discard Deletion")
    print("------------------------------------------------------")
    #confirm deletion
    confirm = str(input("Enter Confirm Selection: "))
    if confirm == "1":
        del library[ISBN]
        print("------------------------------------------------------")
        print("Entry Deleted Successfully")
    elif confirm == "2" :
        pass
    else :
        print("------------------------------------------------------")
        print("Error : That is not a valid mode selection")

#function to update details about a book
def updatebook(ISBN,book_info):
    updating = True
    while updating :
        #allow users to choose what details to update
        print("------------------------------------------------------")
        printdetails(ISBN,book_info)
        print("------------------------------------------------------")
        print("Type 1 to Update Book Title")
        print("Type 2 to Update Author")
        print("Type 3 to Update Genre")
        print("Type 4 to Update Publication Year")
        print("Type 5 to Update Amount")
        print("Type 6 to Stop Updating")
        print("------------------------------------------------------")
        update = str(input("Enter Update Selection: "))
        if update == "1" :
            library[ISBN]["title"] = str(input("Enter New Book Title: ")).title()
        elif update == "2" :
            library[ISBN]["author"] = str(input("Enter New Book Author: ")).title()
        elif update == "3" :
            library[ISBN]["genre"] = str(input("Enter New Book Genre: ")).title()
        elif update == "4" :
            library[ISBN]["year"] = int(input("Enter New Book Publication Year : "))
        elif update == "5" :
            library[ISBN]["amount"] = int(input("Enter New Book Amount : "))
            library[ISBN]["availible"] = (int( library[ISBN]["amount"]) - int(library[ISBN]["loaned"]))
        elif update == "6" :
            updating = False
        else :
            print("------------------------------------------------------")
            print("Error : That is not a valid mode selection")
    
#function used to filter books or search books using the 5 features stored with the book
def filterbook():
    #immediately pyushes the users out once it detects the library has nothing
    if len(library) == 0 : 
        filter = False
        return ("XxX","XxX")
    else :
        filter = True
    search = 0
    while filter :
        list = {}
        list = library.copy()
        listdelete = []
        #we make a copy of the dictionary, this will be our "result" page
        #when user enters the information, it will delete any books that doesnt match our information in the copy"
        #then we list the copy as the search result to the user
        #finally when we choose to update, we can use the ACTUAL library to update
        print("------------------------------------------------------")
        print("Type 1 to Search Using ISBN")
        print("Type 2 to Search Using Book Title")
        print("Type 3 to Filter using Author")
        print("Type 4 to Filter Using Genre")
        print("Type 5 to Filter Using Publication Year")
        print("Type 6 to Filter Using Amount")
        print("Type 7 to Filter Using Loaned Amount")
        print("Type 8 to Stop Searching")
        print("------------------------------------------------------")
        mode = str(input("Enter Selection: "))
        if mode == "1":
            print("------------------------------------------------------")
            search = str(input("Enter Book ISBN: "))
            for ISBN, book_info in list.items():
                if ISBN != search :
                    listdelete.append(ISBN) 
        elif mode == "2" :
            print("------------------------------------------------------")
            search = str(input("Enter Book Title: ")).title()
            for ISBN, book_info in list.items():
                if list[ISBN]["title"] != search :
                    listdelete.append(ISBN)
        elif mode == "3" :
            print("------------------------------------------------------")
            search = str(input("Enter Book Author: ")).title()
            for ISBN, book_info in list.items():
                if list[ISBN]["author"] != search :
                    listdelete.append(ISBN)    
        elif mode == "4" :
            print("------------------------------------------------------")
            search = str(input("Enter Book Title: ")).title()
            for ISBN, book_info in list.items():
                if list[ISBN]["genre"] != search :
                    listdelete.append(ISBN)
        elif mode == "5" :
            print("------------------------------------------------------")
            search = int(input("Enter Book Publication Year: "))
            for ISBN, book_info in list.items():
                if list[ISBN]["year"] != search :
                    listdelete.append(ISBN)
        elif mode == "6" :
            print("------------------------------------------------------")
            search = int(input("Enter Book Amount: "))
            for ISBN, book_info in list.items():
                if list[ISBN]["amount"] != search :
                    listdelete.append(ISBN)
        elif mode == "7" :
            print("------------------------------------------------------")
            search = int(input("Enter Book Loaned Amount: "))
            for ISBN, book_info in list.items():
                if list[ISBN]["loaned"] != search :
                    listdelete.append(ISBN) 
        elif mode == "8" :
            return("","")
            break
        else :
            print("------------------------------------------------------")
            print("Error : That is not a valid mode selection") 
        #deleting every result that doesnt match
        for x in listdelete :
            del list[x]
        #if there is a search result, the print it out
        if len(list) > 0 :
            print("------------------------------------------------------")
            print("List of all Results:")
            for ISBN, book_info in list.items():
                print("------------------------------------------------------")
                printdetails(ISBN,book_info)
            print("------------------------------------------------------")
            print("There are",len(list),"results")
            print("Enter 1 to Confirm Chosen Book, Enter 2 To Apply Different Filters or Leave")
            print("Note : If there are multiple results, the first listed result will be chosen")
            print("------------------------------------------------------")
            confirm = str(input("Enter Confirmation: "))
            if confirm == "1" :
                filter = False
                for ISBN, book_info in list.items():
                    x = ISBN
                    y = book_info
                    return (x,y)
            elif confirm == "2" :
                pass
            else :
                print("------------------------------------------------------")
                print("Error : That is not a valid mode selection")
        else :
            print("------------------------------------------------------")
            print("There are no results")

#function for searching book, then deleting it or updating it depending on the user choice 
def searchbook(): 
    x,y = filterbook()
    if x == "XxX" and y == "XxX" :
        print("------------------------------------------------------")
        print("There are No Books in The Library")
    elif x == "" and y == "" :
        pass
    else :
        #once the filterbook feature has filtered a book, we can choose to either update it or remove it
        print("Type 1 to Update This Entry")
        print("Type 2 to Remove This Entry")
        print("Type 3 to Do Neither")
        print("------------------------------------------------------")
        mode2 = str(input("Enter Mode Selection: "))
        if mode2 == "1" :
            updatebook(x,y)
        elif mode2 == "2" :
            removebook(x)
        elif mode2 == "3" :
            pass
        else :
            print("------------------------------------------------------")
            print("Error : That is not a valid mode selection")

#function for loaning a book or returning a book
def loanbook(): 
    x,y = filterbook()
    if x == "XxX" and y == "XxX" :
        print("------------------------------------------------------")
        print("There are No Books in The Library")
    elif x == "" and y == "" :
        pass
    else :
        print("How many would you like to loan/return?")
        print("You can loan up to",y["availible"],"of this book")
        print("You can return up to",y["loaned"],"of this book")
        print("Insert a negative number to return book")
        print("------------------------------------------------------")
        amount = int(input("Enter Loan/Return Amount: "))
        #if user entered a negative amount, we return it
        #if user positive amount, we loan it instead
        if amount >= 0 and amount <= y["availible"]:
            #loaning
            print("------------------------------------------------------")
            print("Confirm to Loan",amount,"of",y["title"],"?")
            print("Type 1 to Confirm")
            print("Type 2 to Discard")
            print("------------------------------------------------------")
            confirm = str(input("Enter Selection: "))
            if confirm == "1":
                library[x]["loaned"] = int(int(library[x]["loaned"]) + amount )
                library[x]["availible"] = int(int( library[x]["amount"]) - int(library[x]["loaned"]))
            elif confirm == "2" :
                pass
            else :
                print("------------------------------------------------------")
                print("Error : That is not a valid mode selection")
        elif amount < 0 and amount >= y["loaned"]: 
            #returning
            print("------------------------------------------------------")
            print("Confirm to Return",amount,"of",y["title"],"?")
            print("Type 1 to Confirm")
            print("Type 2 to Discard")
            print("------------------------------------------------------")
            confirm = str(input("Enter Selection: "))
            if confirm == "1" :
                library[x]["loaned"] = int(int(library[x]["loaned"]) + amount )
                library[x]["availible"] = int(int( library[x]["amount"]) - int(library[x]["loaned"]))
            elif confirm == "2" :
                pass
            else :
                print("------------------------------------------------------")
                print("Error : That is not a valid mode selection")
        else :
            print("Error : Amount Not Valid")

#function for listing every book in the library   
def listlibrary():
    print("------------------------------------------------------")
    print("List of all results:")
    for ISBN, book_info in library.items():
        print("------------------------------------------------------")
        printdetails(ISBN,book_info)

#main function 
def main():
    running = True
    while running :
        exit = ""
        #choosing mode for function
        print("------------------------------------------------------")
        print("Type 1 to Add a New Entry")
        print("Type 2 to Search then Delete/Update an Entry")
        print("Type 3 to Display Every Book")
        print("Type 4 to Search and Loan/Return a Book")
        print("Type 5 to Exit Program")
        print("------------------------------------------------------")
        mode = str(input("Enter Selection: "))
        if mode == "1" :
            print("------------------------------------------------------")
            addbook(str(input("Enter Book ISBN: ")))
        if mode == "2" :
            searchbook()
        elif mode == "3" :
            listlibrary()
        elif mode == "4" :
            loanbook()
        elif mode == "5" :
            pass
        elif mode != "1" and mode != "2" and mode != "3" and mode != "4" and mode != "5":
            print("------------------------------------------------------")
            print("Error : That is not a valid mode selection")
        #keep the user in a loop so the library program doesnt shut down by itself
        while exit != "1" and exit != "2" :
            print("------------------------------------------------------")
            print("Do you want to continue or exit the program?")
            print("Type 1 to Continue")
            print("Type 2 to Exit")
            print("------------------------------------------------------")
            exit = str(input("Enter Selection: "))
            if exit == "1" :
                with open(file_path, 'w') as file:
                    json.dump(library, file)
                running = True
            elif exit == "2" :
                print("------------------------------------------------------")
                print("Library Program Ended")
                print("------------------------------------------------------")
                running = False
                with open(file_path, 'w') as file:
                    json.dump(library, file)
            else : 
                print("Error : That is not a valid mode selection")
      
#main function      
main()