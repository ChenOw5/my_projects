import pygame
import tkinter as tk
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
import time
from mutagen.mp3 import MP3
import random

def musicplayer(file,playlist):
    main = tk.Tk()
    main.title("OwSounds")
    pygame.mixer.init()
    main.geometry("500x350")
    main.resizable(False,False)
    menu = Menu(main)
    main.config(menu=menu)

    #file path
    global file_path, user_playlist
    file_path = file
    user_playlist = playlist

    #declear global variables
    global playing,paused,time2,slider_moved,current_time,looping, shuffling, shufflelist, count
    playing = -1
    paused = False
    slider_moved = False
    current_time = 0
    looping = False
    shuffling = False
    shufflelist = []
    count = 0
    
    #load the user playlist
    def playlist_load():
        for song in user_playlist :
            song_box.insert(END,song)
    
    #update playlist whenever theres a change
    def update_playlist():
        global user_playlist
        user_playlist = [song_box.get(i) for i in range(song_box.size())]

    #define a function used by all functions that plays a song
    def play1():
        global paused,time2,song_length,playing,current_time, count
        #update pause button to unpause
        count += 1
        if paused:
            pause()
        #get new song and update text label
        song = song_box.get(playing)
        label.config(text=f"Playing {song}")
        label.update()
        #reset current time
        current_time = 0
        #get song new total time length and update it 
        song = f"{file_path}\{song}.mp3"
        song_length = MP3(song).info.length
        song_length = int(song_length)
        time2 = time.strftime('%H:%M:%S',time.gmtime(song_length))  
        duration_bar2.config(text=f'{time2}')
        duration_bar2.update()
        #start timer
        play_time(count)

    #clear the current playing song green highlight
    def clear_highlight():
        for i in range(song_box.size()):
            song_box.itemconfig(i, {'bg': 'white'})

    #command for adding songs
    def addsong():
        global file_path, shuffling, playing, shufflelist
        song = filedialog.askopenfilename(initialdir=file_path,title="Insert Song",filetypes=(("mp3 Files","*.mp3"),))
        song = song.replace("\\", "/").replace(file_path.replace("\\","/")+"/", "").replace(".mp3", "")
        song_box.insert(END,song)
        update_playlist()
        #reshuffle if a new song is added
        if shuffling :
            shuffle1(playing)
        
    #command for adding multiple songs
    def addmanysong():
        global file_path,  shuffling, playing, shufflelist
        songs = filedialog.askopenfilenames(initialdir=file_path,title="Insert Song",filetypes=(("mp3 Files","*.mp3"),))
        for song in songs:
            song = song.replace("\\", "/").replace(file_path.replace("\\","/")+"/", "").replace(".mp3", "")
            song_box.insert(END,song)
        update_playlist()
        #reshuffle if a new song is added
        if shuffling :
            shuffle1(playing)

    #command for removing selected songs
    def removesong():
        global playing,shufflelist,shuffling,count
        #if a song is selected, delete selected song
        if song_box.curselection():
            #if the selected song IS the currently playing song, stop 
            if song_box.curselection()[0] == playing :
                count = 0
                playing = -1
                pygame.mixer.music.stop()
                #reset label
                label.config(text="No Song Is Playing")
                label.update()
                current_time = 0
                #reset timer
                time1 = time.strftime('%H:%M:%S',time.gmtime(current_time))      
                duration_bar1.config(text=f'{time1}')
                slider.set(0)
                #reset shuffle
                shufflelist = []
            # if it is not and shuffle is on, then we reshuffle without affecting the current song
            elif shuffling :
                shufflelist.remove(song_box.curselection()[0])
                #move the index up by one since a song is removed
                shufflelist = [x - 1 if x > song_box.curselection()[0] else x for x in shufflelist]
            song_box.delete(ACTIVE)
        else:
            messagebox.showerror("Error","No Song Selected")
        update_playlist()
            
    #command for removing all songs and stopping the songs and reset 
    def removeallsong():
        global playing,shufflelist,count
        song_box.delete(0, tk.END)
        pygame.mixer.music.stop()
        #update labels
        label.config(text="No Song Is Playing")
        label.update()
        #reset timers
        count = 0
        playing = -1
        current_time = 0
        time1 = time.strftime('%H:%M:%S',time.gmtime(current_time))      
        duration_bar1.config(text=f'{time1}')
        slider.set(0)
        shufflelist = []
        update_playlist()

    #command to start and play a song
    def play():
        global file_path,playing,paused,shuffling,shufflelist
        #error check if there is a song in the playlist
        if song_box.size() == 0:
            messagebox.showerror("Error","No Songs In Playlist")
            return
        #if user did choose a song, then choose that active song, else choose the first song
        if song_box.curselection():  
            song = song_box.get(ACTIVE)
        elif playing == -1 and shuffling == False:
            song_box.selection_set(0) 
            song = song_box.get(0)
        elif playing == -1 and shuffling == True:
            hehe = random.randint(0,song_box.size()-1)
            song_box.selection_set(hehe) 
            song = song_box.get(hehe)
        #load the song
        song = f"{file_path}\{song}.mp3"
        pygame.mixer.music.load(song)
        pygame.mixer.music.play(loops=0)
        playing = song_box.curselection()[0]
        #if it is shuffling, shuffle the playlist with the playing song as the first song
        if shuffling :
            shuffle1(playing)
        clear_highlight()
        song_box.itemconfig(playing, {'bg': 'lime'})
        play1()

    #command for pausing and unpasuing a song 
    def pause():
        global paused,playing
        #if it starts playing
        if playing != -1:
            #if it is not pasued, then pause
            if paused == False:
                pygame.mixer.music.pause()
                paused = True
                #update pause button
                pause_button.configure(image=continuebtn,background="white")
                pause_button.update()
                #update label
                text = label.cget("text")
                text1 = text.replace("Playing", "Paused")
                label.config(text=text1)
                label.update()
            else :
                pygame.mixer.music.unpause()
                paused = False
                #update pause button
                pause_button.configure(image=pausebtn,background="white")
                pause_button.update()
                #update label
                text = label.cget("text")
                text1 = text.replace("Paused", "Playing")
                label.config(text=text1)
                label.update()

    
    #command for going to the next song in the listbox 
    def next_song():
        global playing,paused,looping,shuffling,shufflelist

        pygame.mixer.music.stop()
        # if it is looping, just set the next song to the current song
        if looping: 
            next = playing
        elif shuffling :
            #if the next index on the shuffle list is empty, then move back to the first song on the shufflelist
            if shufflelist.index(playing) == len(shufflelist)-1:
                next = shufflelist[0]
            else:
                # if it is on shuffle, move to the next index on the shuffled list
                x = shufflelist.index(playing) + 1
                next = shufflelist[x]
        #if the next song is empty and not shuffled, move back to the first song
        elif playing == song_box.size()-1:
            next = 0
        else :
            next = playing + 1
        
        #load song and play
        song = song_box.get(next)
        song = f"{file_path}\{song}.mp3"
        pygame.mixer.music.load(song)
        pygame.mixer.music.play(loops=0)
        playing = next
        clear_highlight()
        song_box.itemconfig(playing, {'bg': 'lime'})
        play1()
        
    #command for going to the previous song in the listbox 
    def previous_song():
        global paused,playing
        #stop the music
        pygame.mixer.music.stop()
        if shuffling :
            #if it is shuffling, and the previous song is emtpy, so to last song in the shuffle list
            if shufflelist.index(playing) == 0:
                prev = shufflelist[-1]
            else:
            #if not, go the previous index of the shuffle list
                x = shufflelist.index(playing) - 1
                prev = shufflelist[x]
        #if the previous song is empty and not shuffled, move back to the last song
        elif playing == 0 :
            prev = song_box.size()-1
        else :
        #if not, move to the previous index
            prev = playing - 1
        #load the song
        song = song_box.get(prev)
        song = f"{file_path}\{song}.mp3"
        pygame.mixer.music.load(song)
        pygame.mixer.music.play(loops=0)
        playing = prev
        #clear highlight
        clear_highlight()
        song_box.itemconfig(playing, {'bg': 'lime'})
        play1()
        
    #command for showing the current duration of the song
    def play_time(local_count):
        global time2,song_length,current_time,slider_moved,paused,count
            
        #when the song is running this function is not equal to the current playing song, end the song's timer
        if(local_count != count):
            return
            
        #update timer
        time1 = time.strftime('%H:%M:%S',time.gmtime(current_time))      
        duration_bar1.config(text=f'{time1}')      
            
        #only run when user is not interacting with the slider
        if slider_moved == False:
            slider.set((current_time/song_length)*100)
        
        #when the song duration is up, go to next song and end the current timer
        if time1 == time2 or int(current_time) - int(song_length) == 0 :
            next_song()
            return

        #update timer
        if not paused:
            current_time += 1
        
        duration_bar1.after(1000, lambda: play_time(local_count))
        
    #function that sets the newtime on the slider to the song's duration 
    def slide(newtime):
        #if a song is playing
        if pygame.mixer.music.get_busy():
            global song_length,current_time,slider_moved
            #set the current time to the new time according to sldider position
            float(newtime)
            newtime1 = (newtime/100)*song_length
            int(newtime1)
            song_length - newtime1
            pygame.mixer.music.play(start=newtime1)
            current_time = newtime1
            #update the timer 
            time1 = time.strftime('%H:%M:%S', time.gmtime(current_time))
            duration_bar1.config(text=f'{time1}')   
            slider.set((current_time / song_length) * 100)
            slider_moved = False
        
    #function that runs when users start to hold down the slider
    def on_slider_move(event):
        global slider_moved
        #set slider moved to true to ensure that the slider doesnt move while the user is adjusting it
        slider_moved = True

    #function that runs once users release from the click when sliding
    def on_slider_release(event):
        global slider_moved
        #run slide command according to the current slider positions
        slide(slider.get())
        slider_moved = False
        
    #function to enable looping of song
    def loop():
        global looping
        if looping:
            #set loop to false and update the button
            looping = False
            loop_button.configure(background="white")
        else:
            #set loop to True and update the button
            looping = True
            loop_button.configure(background="lime")

    #function for the shuffle function, activate shuffle or not
    def shuffle():
        global playing, shuffling, shufflelist
        #remove shuffling and remove the entire list
        if shuffling:
            shufflelist = []
            shuffling = False   
            shuffle_button.configure(background="white")
        else:
            #activate shuffling, and if the song hasnt played yet, create a shuffle
            shuffling = True
            shuffle_button.configure(background="lime")
            if playing != -1:
                shuffle1(playing)
            
    #function for shuffling and generating the new shuffle list
    def shuffle1(y):
        global shuffling, shufflelist,playing
        #remove the current shuffle
        shufflelist = []
        #make sure the first song in the shuffle, is the currently playing song
        shufflelist.append(y)
        #while loop to add all the other songs
        while len(shufflelist) != song_box.size():
            x = random.randint(0,song_box.size()-1)
            #if else statement to make sure that no repeating songs
            if x not in shufflelist:
                shufflelist.append(x)
            else:
                continue
            
    #function for adjusting volume
    def volume(x):
        #set label to volume
        volume_label.config(text=int(x))
        x = float(x)
        #set volume to the slider value
        pygame.mixer.music.set_volume(x/100)
        #set corresponding image according to volume
        if x == 100 :
            volume_image.config(image=full_volumebtn)
        elif x >= 50 and x <= 99 :
            volume_image.config(image=high_volumebtn)
        elif x >= 1 and x < 50 :
            volume_image.config(image=low_volumebtn)
        elif x == 0 :
            volume_image.config(image=no_volumebtn)
        volume_image.update()
            

    #images needed
    playbtn = PhotoImage(file=r"resources\playbutton.png")
    pausebtn = PhotoImage(file=r"resources\pausebutton.png")
    continuebtn = PhotoImage(file=r"resources\continuebutton.png")
    nextbtn = PhotoImage(file=r"resources\nextbutton.png")
    previousbtn = PhotoImage(file=r"resources\previousbutton.png")
    loopbtn = PhotoImage(file=r"resources\loopbutton.png")
    shufflebtn = PhotoImage(file=r"resources\shufflebutton.png")
    full_volumebtn = PhotoImage(file=r"resources\full_volume.png")
    high_volumebtn = PhotoImage(file=r"resources\high_volume.png")
    low_volumebtn = PhotoImage(file=r"resources\low_volume.png")
    no_volumebtn = PhotoImage(file=r"resources\no_volume.png")

    #buttons creation
    song_box = Listbox(main,bg="white",fg="black",selectbackground="yellow",selectforeground="black")
    play_button = tk.Button(main,command=play,image=playbtn)
    pause_button = tk.Button(main,command=pause,image=pausebtn)
    next_button = tk.Button(main,image=nextbtn,command=next_song)
    previous_button = tk.Button(main,image=previousbtn,command=previous_song)
    loop_button = tk.Button(main,image=loopbtn,command=loop,background="white")
    shuffle_button = tk.Button(main,image=shufflebtn,background="white",command=shuffle)
    
    #menu add song and remove songs
    add_song_menu = Menu(menu)
    remove_song_menu = Menu(menu)
    menu.add_cascade(label="Insert Songs",menu=add_song_menu)
    menu.add_cascade(label="Remove Songs",menu=remove_song_menu)
    add_song_menu.add_command(label="Add A Song To Playlist",command=addsong)
    add_song_menu.add_command(label="Add Songs To Playlist",command=addmanysong)
    remove_song_menu.add_command(label="Remove Selected Song",command=removesong)
    remove_song_menu.add_command(label="Remove All Songs",command=removeallsong)
    
    #timers
    duration_bar1 = Label(main,text="00:00:00",bd=1,relief=GROOVE)
    duration_bar2 = Label(main,text="00:00:00",bd=1,relief=GROOVE)
    slider = tk.Scale(main,from_=0,to=100,orient=HORIZONTAL,showvalue=False,sliderlength=10)
    slider.bind("<ButtonPress-1>", on_slider_move)
    slider.bind("<ButtonRelease-1>", on_slider_release)
    label = tk.Label(main,text="No Song Is Playing")
    
    #volume slider
    volume_slider = tk.Scale(main,from_=100,to=0,orient=VERTICAL,showvalue=False,sliderlength=20,command=volume)
    volume_slider.set(50)
    volume_label = tk.Label(main,text="50")
    volume_image = tk.Label(image=high_volumebtn)


    #widget place
    song_box.place(anchor=CENTER,rely=0.3,relx=0.5,relwidth=0.75)
    loop_button.place(relx=0.125,rely=0.75)
    previous_button.place(relx = 0.2526, rely=0.75)
    pause_button.place(relx=0.3802,rely=0.75)
    play_button.place(relx = 0.5079, rely = 0.75)
    next_button.place(relx = 0.6354, rely = 0.75)
    shuffle_button.place(relx = 0.763, rely = 0.75 )
    duration_bar1.place(relx=0.125,rely = 0.65)
    duration_bar2.place(relx=0.783,rely = 0.65)
    slider.place(relx=0.225,rely = 0.645,relwidth=0.55)
    label.place(anchor=CENTER,relx=0.5,rely=0.6)
    volume_slider.place(rely=0.06,relx=0.9175,relheight=0.75)
    volume_label.place(rely=0.8,relx=0.915)
    volume_image.place(relx = 0.905,rely = 0.85) 
    
    playlist_load()
    main.mainloop()
    pygame.mixer_music.stop()
    return user_playlist