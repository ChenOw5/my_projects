import pygame
import tkinter as tk
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
import time
from mutagen.mp3 import MP3
import random
import musicplayer
import json
global value
value = 1

#enter the song_db FILE PATH here 
song_db = r""

#dont touch this
user_db = r"user_db.json"

def mainlogin(x,y):
    song_db = x
    user_db = y

    #load file
    with open(user_db,"r") as file:
        users = json.load(file)

    #set up window
    login = tk.Tk()
    login.title("OwSounds - Register/Log In")
    login.geometry("500x350")
    login.resizable(False,False)
    menu = Menu(login)
    login.config(menu=menu)
    global showed,value
    showed = False

    #load the changes into the json file
    def exit():
        with open(user_db, 'w') as file:
            json.dump(users, file)

    #show and hide the password for users 
    def show():
        global showed
        if showed == False:
            showed = True
            password_entry.config(show="")
            show_password_button.config(text="Hide Password")
        elif showed == True:
            showed = False
            password_entry.config(show="*")
            show_password_button.config(text="Show Password")
        password_entry.update()
        show_password_button.update()

    #code for registering a new user
    def register():
        global value
        x = {}
        email = email_entry.get()
        password = password_entry.get()
        #check if valid syntax
        if email.endswith("@gmail.com"):
            pass
        else:
            messagebox.showerror("Error","Wrong Email Format. Must End In @gmail.com")
            return
        #if the email is not in the databse, pass, else error
        if email not in users:
            #store password and create new playlist
            x['password'] = f"{password}"
            x['playlist'] = []
            users[f"{email}"] = x
            login.destroy()
            value = 1
            #load the playlist for user
            playlist = users[f"{email}"]["playlist"]
            #store the playlist when user exits the application
            users[f"{email}"]["playlist"] = musicplayer.musicplayer(song_db,playlist)
            #store songs
            exit()
        else :
            messagebox.showerror("Error","This email has signed up to another account")

    #logging in function
    def log_in():
        global value
        email = email_entry.get()
        password = password_entry.get()
        #check syntax
        if email.endswith("@gmail.com"):
            pass
        else:
            messagebox.showerror("Error","Wrong Email Format. Must End In @gmail.com")
            return
        #if the email is in users and password matches, pass
        if email in users and password == users[f"{email}"]["password"]:
            login.destroy()
            value = 1
            #load the playlist for user
            playlist = users[f"{email}"]["playlist"]
            #store the playlist when user exits the application
            users[f"{email}"]["playlist"] = musicplayer.musicplayer(song_db,playlist)
            exit()
        #if password not match, then error
        elif email in users and password != users[f"{email}"]["password"]:
            messagebox.showerror("Error","Incorrect Password or User Email")
        #else show that this email is not registered
        else:
            messagebox.showerror("Error","This account does not exist. Try Registering.")

    #creating widgets
    title = tk.Label(login,text="Welcome to OwSounds",font=("Calibri",36))
    email_label = tk.Label(login,text="Enter Email:")
    email_entry = tk.Entry(login,width=40)
    password_label = tk.Label(login,text="Enter Password:")
    password_entry = tk.Entry(login,width=40,show="*")
    show_password_button = tk.Button(login,text="Show Password",command=show)
    register_button = tk.Button(login,text="Register",command=register)
    login_button = tk.Button(login,text="Log In",command=log_in)

    #packing widgets
    title.place(anchor=CENTER,rely=0.2,relx=0.5)
    email_label.place(rely = 0.5,relx=0.188)
    email_entry.place(rely = 0.5,relx=0.324)
    password_label.place(rely = 0.6,relx=0.150)
    password_entry.place(rely = 0.6,relx=0.324)
    show_password_button.place(rely=0.59,relx=0.81)
    register_button.place(rely = 0.775,relx=0.5,anchor=CENTER)
    login_button.place(rely = 0.7,relx=0.5,anchor=CENTER)
    
    login.mainloop()
    
    exit()

#when user exits the music player, keep showing the login pageuntil the user CLOSES the login page
while value == 1:
    value = 0
    mainlogin(song_db,user_db)