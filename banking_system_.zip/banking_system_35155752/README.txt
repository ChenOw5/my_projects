HOW TO USE?

- enter numbers to choose what action you would like to perform
- each action has a number beside it, enter the number to choose that action
- entering anything other than the number (characters, spaces only) will cause an error and you will be asked to do it again
- if the program ask for an input, enter the correct input
( if it asks for an ID number, and your input is not a number, then you will be asked to enter a number again ) 
( you can enter numbers as your name, but whatever floats your boat I guess ) 

LIMITATIONS AND SOME BUGS

- the amount of money an account can have has a limit, if the balance passes this limit, depositing and withdrawal will not work (limit is about 15-16 digits)
- ID number can only have digits, but if input is "2019 xxxx", it will only read the numbers. So it doesn't detect the invalid input (the letters), but it wont give an error