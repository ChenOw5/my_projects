#include <stdio.h>
#include <stdlib.h>
#include "bank_header.h"
//intialize some varaibles that will be used repeatedly

int menuui(){
    int res;

    //loop users until they put a valid input
    //provide a valid UI
    while(1){
        res = 0;
        printf("1 - Create New Bank Account\n");
        printf("2 - Delete Bank Account\n");
        printf("3 - Deposit \n");
        printf("4 - Withdrawal \n");
        printf("5 - Remittance\n");
        printf("6 - Exit Bank Account System\n");
        printf("------------------------------------------------\n");
        printf("Enter Selection (1-6): ");
        res = scan_int();
        printf("------------------------------------------------\n");
        if (res >= 1 && res <= 6){
            break;
        }else{
            printf("Error : Invalid Input/Input Not In Range of 1-6\n");
            printf("------------------------------------------------\n");
            continue;
        }
    }
    return res;
}

void createacc(){
    //create a random account number that DOESNT exist in the database yet 
    // this is achive through loop and my check_file function
    while (1){
        accnum = (rand() % (990000+1)) + 10000 ;
        sprintf(acc, "%d", accnum);
        filename = acc;
        if ( check_file(filename) ){
            continue;
        } else{
            create_file(filename);
            break;
        }
    }
    //once confirmed, create the datatypes to store user input
    //and create the filepath needed
    char name[100];
    char id[100];
    int idcheck = 0;
    int confirm = 0;
    int acctype;
    sprintf(fullpath, "%s%s%s", fileprefix, filename,filesuffix);
    FILE *fp = fopen(fullpath, "w");  
    //keep users in a loop till they input a valid name
    //for this function, users are in a loop because their information CANNOT be null
    while (1){
        printf("Enter Your Name: ");
        if (fgets(name, sizeof(name), stdin)){
            // check if first character is empty
            if (name[0] == '\n') {
                printf("------------------------------------------------\n");
                printf("Error: Invalid Input\n");
                printf("------------------------------------------------\n");
            }else{
                //check if rest of the characters is empty or null, if yes then break
                int i = 0;
                while (name[i] != '\n' && name[i] != '\0') {
                    i++;
                }
                if (name[i] == '\n') {
                    name[i] = '\0';
                }
                break;
            }
        }else{
            printf("------------------------------------------------\n");
            printf("Error: Invalid Input\n");
            printf("------------------------------------------------\n");
            //  clear the rest of the input using the same thing from my scan int function
            for ( int c; c = getchar(), c != '\n' && c != EOF; )
                ;
        }
    }
    printf("------------------------------------------------\n");
    //repeat it for the ID and account type
    //scan id as string, because 0001 would be converted to 1 otherwise
    while (1){
        confirm = 1;
        printf("Enter Your Identification Number (ID): ");
        scanf("%s",&id);
        //check if it is a valid integer
        for (int i = 0; id[i] != '\0'; i++) {
            if (id[i] >= '0' && id[i] <= '9') {
                ;
            }
            else {
                printf("------------------------------------------------\n");
                printf("Error: Invalid Input, Not A Number\n");
                printf("------------------------------------------------\n");
                confirm = 0;
                break;
            }
        }
        //only break the loop if no error is found with the number and confirmed
        while (getchar()!='\n');
        if (confirm == 1){
            break;
        }else{
            continue;
        }
    }
    //allow users to choose the type of bank account they want
    // i use 243 so that users really wanna confirm it
    while (1){
        printf("------------------------------------------------\n");
        printf("|| Types of Bank Account ||\n");
        printf("243 - Savings Account\n");
        printf("325 - Current Account\n");
        printf("------------------------------------------------\n");
        printf("Choose Your Account Type: ");
        acctype = scan_int();
        //check if input is valid, then assign the account type
        if(acctype == 243){
            acctype = 0;
            break;
        }else if(acctype == 325){
            acctype = 1;
            break;
        }
        else{
            printf("------------------------------------------------\n");
            printf("Error: Invalid Input\n");
        }
    }
    //write the data into the corresponding file
    fprintf(fp,"%.2f\n",0.00);
    fprintf(fp,"%s\n",name);
    fprintf(fp,"%s\n",id);
    fprintf(fp,"%d",acctype);
    //finally print out a confirm message to confirm the creation of the account
    //then print out the account number so that users can record it down for future use
    printf("------------------------------------------------\n");
    printf("|| Bank Account Successfully Created || \n");
    printf("|| Bank Account Number : %d || \n",accnum);
    printf("------------------------------------------------\n");
    fclose(fp);
}

void delacc(){
    int confirm;
    printf("Enter Bank Account Number: ");

    //error checking to check if account exist

    accnum = scan_int();
    if ( checkacc(accnum)){
        ;
    }else{
        return;
    }
    //asking again to confirm user's actions to delete this account
    //user must type their bank account number again because I do not want "1" as a confirm button
    //it might become too east to accidentally delete account
    displayacc(accnum);
    printf("Are you ABSOLUTELY SURE you want to delete this account?\n");
    printf("0 - Discard Action\n");
    printf("%d - Confirm Action\n",accnum);
    printf("------------------------------------------------\n");
    printf("Enter Selection: ");
    confirm = scan_int();
    printf("------------------------------------------------\n");

    //if action is confirmed, then call the delete file function, any other input will be discarded
    if (confirm == accnum){
        if(delete_file(accnum)){
            printf("|| Bank Account Successfully Deleted ||\n");
        }else{
            printf("|| Error : Bank Account Deletion Error ||\n");
            printf("|| Please Try Again ||\n");
        }
    }else{
        printf("|| Action Discarded ||\n");
    }
    printf("------------------------------------------------\n");
}

void deposit(){
    int confirm;
    double balance;
    double amount;
    printf("Enter Bank Account Number: ");
    //error checking to check if account exist
    accnum = scan_int();
    if ( checkacc(accnum)){
        ;
    }else{
        return;
    }
    //display account to make sure it is theirs
    displayacc(accnum);
    printf("Do you confirm this is your account?\n");
    printf("0 - Discard\n");
    printf("%d - Confirm\n",accnum);
    printf("------------------------------------------------\n");
    printf("Enter Selection: ");
    //confirm selection, any other input is discarded
    confirm = scan_int();
    if (confirm != accnum){
        printf("|| Action Discarded ||\n");
        printf("------------------------------------------------\n");
        return;
    }
    //display the current balance of the user and loop them till they put a valid input
    while(1){
        printf("------------------------------------------------\n");
        balance = displaybalance(accnum);
        printf("Enter Amount to Deposit Into Account: ");
        amount = scan_double();
        if (amount < 0){
            printf("------------------------------------------------\n");
            printf("Error: Invalid Input\n");
            continue;
        }else{
            break;
        }
    }
    // after the amount is valid, we call the rewrite balance function and rewrite it
    balance = rewritebalance(accnum,amount,0);
    //print out a message saying the process was successful and the new balance of the user
    printf("------------------------------------------------\n");
    printf("%.2lf Successfully Deposit Into Account\n",amount);
    printf("New Account Balance : %.2lf\n",balance);
    printf("------------------------------------------------\n");
}

void withdraw(){
    //decleare variables
    int confirm;
    double balance;
    double balance1;
    double amount;
    printf("Enter Bank Account Number: ");
    //error checking to check if account exist
    accnum = scan_int();
    if ( checkacc(accnum)){
        ;
    }else{
        return;
    }
    //display account to make sure it is theirs
    displayacc(accnum);
    printf("Do you confirm this is your account?\n");
    printf("0 - Discard\n");
    printf("%d - Confirm\n",accnum);
    printf("------------------------------------------------\n");
    printf("Enter Selection: ");
    //ask for confirmation
    confirm = scan_int();
    if (confirm != accnum){
        printf("|| Action Discarded ||\n");
        printf("------------------------------------------------\n");
        return;
    }
    printf("------------------------------------------------\n");
    //keep user in loop till they put a valid input to withdraw
    // show the users current balance to make it easier
    while(1){
        balance = displaybalance(accnum);
        balance1 = balance;
        printf("Enter Amount to Withdraw From Account: ");
        amount = scan_double();
        if (amount < 0){
            printf("------------------------------------------------\n");
            printf("Error: Invalid Input\n");
            continue;
        }else{
            break;
        }
    }
    //once input is valid, we rewrite the balance
    balance = rewritebalance(accnum,amount,1);
    //the balance function returns a negative value, meaning theres an error 
    // the function itself will prnit insufficient balance
    // we show the account balance being unchanged
    if (balance < 0){
        printf("Withdrawal Process Failed\n");
        printf("Account Balance : %.2lf\n",balance1);
    }else{
        //else the money is withdrawn, and we show the new balance to the user
        printf("------------------------------------------------\n");
        printf("%.2lf Successfully Withdrawned From Account\n",amount);
        printf("New Account Balance : %.2lf\n",balance);
    }
    printf("------------------------------------------------\n");
}

void remittance(){
    //declease variable
    int confirm;
    double balance;
    double balance1;
    double amount;
    printf("Enter Bank Account Number: ");
    //error checking to check if account exist
    accnum = scan_int();
    if ( checkacc(accnum)){
        ;
    }else{
        return;
    }
    //display account to make sure it is theirs
    displayacc(accnum);
    printf("Do you confirm this is your account?\n");
    printf("0 - Discard\n");
    printf("%d - Confirm\n",accnum);
    printf("------------------------------------------------\n");
    printf("Enter Selection: ");
    //ask for confirmation
    confirm = scan_int();
    if (confirm != accnum){
        printf("|| Action Discarded ||\n");
        printf("------------------------------------------------\n");
        return;
    }
    //ask for the receiver account number
    printf("------------------------------------------------\n");
    printf("Enter Receiver's Bank Account Number: ");
    //error checking to check if account exist else we break out this function
    accnum1 = scan_int();
    if ( checkacc(accnum)){
        ;
    }else{
        return;
    }
    //if both account number is the same, we say no because not allowing transffering money to the same account
    if (accnum1 == accnum){
        printf("------------------------------------------------\n");
        printf("Error : Cannot transfer money to the same account\n");
        printf("------------------------------------------------\n");
        return;
    }
    //display account to make sure it is theirs
    //use displayname to only show the name and account types
    displayname(accnum1);
    printf("Do you confirm this is the name of the receiver?\n");
    printf("0 - Discard\n");
    printf("%d - Confirm\n",accnum1);
    printf("------------------------------------------------\n");
    //ask for confirmaion
    printf("Enter Selection: ");
    confirm = scan_int();
    if (confirm != accnum1){
        printf("|| Action Discarded ||\n");
        printf("------------------------------------------------\n");
        return;
    }
    while(1){
        //keep user in a while loop, showing thebalance of sender and the remittance fee
        printf("------------------------------------------------\n");
        printf("Savings --> Current : 2% Remittance Fee From Sender\n");
        printf("Current --> Savings : 3% Remittance Fee From Sender\n");
        balance = displaybalance(accnum);
        printf("Enter Amount to Transfer: ");
        //check valid amount
        amount = scan_double();
        if (amount < 0){
            printf("------------------------------------------------\n");
            printf("Error: Invalid Input\n");
            continue;
        }else{
            break;
        }
    }
    //once the value is confirmed, we can transfer the money
    transfer(accnum,accnum1,amount);
}

void exitsystem(){
    //no comment just printing an exit statement
    printf("Thank you for using this Bank Account System\n");
    printf("Your return will be awaited\n");
    printf("------------------------------------------------\n");
    printf("|| Bank Account System Shut Down || \n");
    printf("------------------------------------------------\n");
}

int main(){

    //keep users in a loop until they choose to leave which is the 6th selection

    int selection;
    printf("------------------------------------------------\n");
    printf("Bank Account System\n");
    printf("------------------------------------------------\n");
    //let user pick their function
    while (1){
        selection = menuui();
        if (selection == 1){
            createacc();
        }
        else if (selection == 2){
            delacc();
        }
        else if (selection == 3){
            deposit();
        }
        else if (selection == 4){
            withdraw();
        }
        else if (selection == 5){
            remittance();
        }
        else if (selection == 6){
            exitsystem();
            break;
        }
        else{
            continue;
        }
    }   
    free;
    return 0;
}