#include <stdio.h>
#include <stdlib.h>

#ifndef bank_header_h
#define bank_header_h

//declare variables to make reading files better
char acc[100];
char fileprefix[] = "database/";  
char filesuffix[] = ".txt";
char fullpath[100]; 
char* filename;
int accnum;
int accnum1;


//function to detect intergers
int scan_int()
{
    int scanned = 0;
    int found_line = 0;
    int res;
    //loop till there is a valid input
    for (;;)
    {   
        //initial scan check
        if ( scanf( "%d", &res ) == 1 ){
            scanned = 1;
        }

        //check if there is any trailling spaces
        if ( getchar() == '\n' ){
            found_line = 1;
        }
        //if both condition is satisfied then we exit the loop
        if ( scanned && found_line)
            break;
        //clear input
        while(getchar()!='\n');

        //if not we return an invalid interger
        return -1;

        //clear any leftover spaces
        if ( !found_line )
        {
            for ( int c; c = getchar(), c != '\n' && c != EOF; )
                ;
        }
    }
    return res;
}

//same as scan int, but double
double scan_double()
{
    int scanned = 0;
    int found_line = 0;
    double res;
    //loop till there is a valid input
    for (;;)
    {   
        //initial scan check
        if ( scanf( "%lf", &res ) == 1 ){
            scanned = 1;
        }

        //check if there is any trailling spaces
        if ( getchar() == '\n' ){
            found_line = 1;
        }
        //if both condition is satisfied then we exit the loop
        if ( scanned && found_line)
            break;
        //clear input
        while(getchar()!='\n');

        //if not we return an invalid interger
        return -1;

        //clear any leftover spaces
        if ( !found_line )
        {
            for ( int c; c = getchar(), c != '\n' && c != EOF; )
                ;
        }
    }
    return res;
}

//function to check if bank account exist
int check_file(const char *filename) {

    //combine files to fullpath directory
    sprintf(fullpath, "%s%s%s", fileprefix, filename,filesuffix);
    
    //open file
    FILE *fp = fopen(fullpath, "r");  
    int exist = 0;
    
    // if it does exist, return a 1, which is true
    if (fp != NULL) {
        exist = 1;
        fclose(fp);  
    }
    
    //return 0 if the if-else statement fails
    return exist;
}

//function to create a file
void create_file(const char *filename){
    //makes a full filename, then opens it 
    //this function is only called when the file doenst exist, therefore it will always open a new file

    FILE *fp;
    sprintf(fullpath, "%s%s%s", fileprefix, filename,filesuffix);
    fp = fopen(fullpath, "w");

    // close the file
    fclose(fp);
}

int delete_file(int accnum){
    //makes a full filename, then removes it 
    sprintf(acc, "%d", accnum);
    filename = acc;
    sprintf(fullpath, "%s%s%s", fileprefix, filename,filesuffix);
    if(remove(fullpath)==0){
        return 1;
    }else{
        return 0;
    }
}

//function to check if account exist
int checkacc(int accnum){

    //check if account number is valid
    if ( accnum >= 10000 && accnum <= 1000000){
        sprintf(acc, "%d", accnum);
        filename = acc;
        //use checkfile to check it is exsit in the databse, else say it is not found
        if ( !check_file(filename) ){
            printf("------------------------------------------------\n");
            printf("Error : Bank Account Not Found\n");
            printf("------------------------------------------------\n");
            return 0;
        }
    }else{
        //else it is an invalid input
        printf("------------------------------------------------\n");
        printf("Error : Invalid Account Number\n");
        printf("------------------------------------------------\n");
        return 0;
    }
    return 1;
}

//function to display account details
void displayacc(int accnum){
    //create the filepath and open it
    sprintf(acc, "%d", accnum);
    filename = acc;
    sprintf(fullpath, "%s%s%s", fileprefix, filename,filesuffix);
    FILE *fp = fopen(fullpath, "r"); 
    char name[100];
    char id[100];
    double balance;
    int type;

    //read the file
    fscanf(fp,"%lf",&balance);
    fscanf(fp," %[^\n]",&name);
    fscanf(fp,"%s",&id);
    fscanf(fp,"%d",&type);

    //print the details
    printf("------------------------------------------------\n");
    printf("|| Bank Account Details ||\n");
    printf("Balance: %.2lf\n",balance);
    printf("Name: %s\n",name);
    printf("ID Number: %s\n",id);
    if (type == 0){
        printf("Account Type: Savings\n");
    }else{
        printf("Account Type: Current\n");
    }
    printf("------------------------------------------------\n");
    //close it
    fclose(fp);
}

//function to show balance whenver user wants to deposite or withdraw money
// also used to get the balance from an account
double displaybalance(int accnum){
    //get the file
    sprintf(acc, "%d", accnum);
    filename = acc;
    sprintf(fullpath, "%s%s%s", fileprefix, filename,filesuffix);
    FILE *fp = fopen(fullpath, "r"); 
    //scan the balance
    double balance;
    fscanf(fp,"%lf",&balance);
    //display balance
    printf("Current Balance: %.2f\n",balance);  
    fclose(fp);
    return balance;
}

//function to rewrite balance, 1 for increase money, 2 for decrease money
double rewritebalance(int accnum, double amount, int mode){
    //open fil
    sprintf(acc, "%d", accnum);
    filename = acc;
    sprintf(fullpath, "%s%s%s", fileprefix, filename,filesuffix);
    FILE *fp = fopen(fullpath, "r"); 
    //define varaibles in the bank account
    char name[100];
    char id[100];
    double balance;
    int type;

    //read the file
    fscanf(fp,"%lf",&balance);
    fscanf(fp," %[^\n]",&name);
    fscanf(fp,"%s",&id);
    fscanf(fp,"%d",&type);
    //if the mode is decrease amount, check if amount is bigger than balance
    // if yes then it is an error so we return
    if (mode == 1){
        if (balance > amount){
            ;
        }
        else {
            printf("------------------------------------------------\n");
            printf("Error : Insufficient Balance\n");
            printf("------------------------------------------------\n");
            return -1;
        }
    }
    //change the balance
    if (mode == 0){
        balance += amount;
    }else if(mode == 1){
        balance -= amount;
    }
    fclose(fp);
    //open the file again as write mode
    FILE *fp1 = fopen(fullpath, "w"); 
    //write the new balance, and the same account details
    fprintf(fp1,"%.2lf\n",balance);
    fprintf(fp1,"%s\n",name);
    fprintf(fp1,"%s\n",id);
    fprintf(fp1,"%d",type);
    fclose(fp1);
    //return the new balance
    return balance;
}

//function to display the name and account type of the receiver account
//i decided to now show all the details for privacy sake
void displayname(int accnum){
    //create the filepath and open it
    sprintf(acc, "%d", accnum);
    filename = acc;
    sprintf(fullpath, "%s%s%s", fileprefix, filename,filesuffix);
    FILE *fp = fopen(fullpath, "r"); 
    //define varaibles
    char name[100];
    char id[100];
    double balance;
    int type;

    //read the file
    fscanf(fp,"%lf",&balance);
    fscanf(fp," %[^\n]",&name);
    fscanf(fp,"%s",&id);
    fscanf(fp,"%d",&type);

    //print the details needed
    printf("------------------------------------------------\n");
    printf("|| Bank Account Details ||\n");
    printf("Name: %s\n",name);
    if (type == 0){
        printf("Account Type: Savings\n");
    }else{
        printf("Account Type: Current\n");
    }
    printf("------------------------------------------------\n");
    //close it
    fclose(fp);
}

//function to transfer money from one account to another
void transfer( int accnum , int accnum1 , double amount){
    //define all the varaibles, 
    char name[100];
    char id[100];
    double balance;
    double balancevar1;
    int type;

    char name1[100];
    char id1[100];
    double balance1;
    int type1;

    double amount1 = amount;
    //open file1
    sprintf(acc, "%d", accnum);
    filename = acc;
    sprintf(fullpath, "%s%s%s", fileprefix, filename,filesuffix);
    FILE *fp = fopen(fullpath, "r"); 
    //open file2
    sprintf(acc, "%d", accnum1);
    filename = acc;
    sprintf(fullpath, "%s%s%s", fileprefix, filename,filesuffix);
    FILE *fp1 = fopen(fullpath, "r"); 
    //scan both files for their data
    fscanf(fp,"%lf",&balance);
    fscanf(fp," %[^\n]",&name);
    fscanf(fp,"%s",&id);
    fscanf(fp,"%d",&type);
    fscanf(fp1,"%lf",&balance1);
    fscanf(fp1," %[^\n]",&name1);
    fscanf(fp1,"%s",&id1);
    fscanf(fp1,"%d",&type1);
    fclose(fp);
    fclose(fp1);

    //set balance var as a temporary variable
    balancevar1 = balance;

    //check the type of account, and then increase the amount according to the remittance fee
    if ( type == 0 && type1 == 1){
        amount *= 1.02;
    }else if(type1 == 0 && type == 1){
        amount *= 1.03;
    }
    //rewrite the balance of the sender account
    balance = rewritebalance(accnum,amount, 1);
    //if there is an issuficient balance, we return and error and break the function
    //also show the total amouunt needed as well as the remittance fee
    if ( balance < 0){
        printf("|| Transfer Process Failed ||\n");
        printf("Remittance Fee : %.2lf\n",amount-amount1);
        printf("Total Amount Needed : %.2lf\n",amount);
        printf("Account Balance : %.2lf\n",balancevar1);
        printf("------------------------------------------------\n");
        return;
    }
    //after the money is successfully transfer from the sender account
    //we can put the money into the receivers account
    //rewrite the balance
    balance1 = rewritebalance(accnum1,amount1, 0);
    //print out the remittance fee and how muhc money is transfer
    printf("------------------------------------------------\n");
    printf("%.2lf Successfully Transferred From Account \nTo %s\n",amount1,name1);
    printf("Remittance Fee : %.2lf\n",amount-amount1);
    printf("------------------------------------------------\n");
    //print out the new balance of the sender's account, not the receiver due to privacy sake
    printf("New Account Balance : %.2lf\n",balance);
    printf("------------------------------------------------\n");
    return;
}

#endif
